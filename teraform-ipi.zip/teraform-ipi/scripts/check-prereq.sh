#!/bin/bash

# Check for all executables
EXECUTABLES="terraform rosa aws"

for E in $EXECUTABLES
do
  WHICH=$(which $E)
  if [ -x "$WHICH" ] ; then
    echo "Found $E at $WHICH"
  else
    echo "$E not found, please install"
    exit 1
  fi
done